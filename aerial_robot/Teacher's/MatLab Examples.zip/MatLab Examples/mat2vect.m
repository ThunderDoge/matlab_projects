function vect= mat2vect(M)
vect=[M(1,:)';M(2,:)';M(3,:)']';
end

