function ave = calculateAverage(x)
    ave = sum(x(:))/numel(x); 
end