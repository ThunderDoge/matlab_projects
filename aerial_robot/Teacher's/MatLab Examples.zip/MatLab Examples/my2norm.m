function n=my2norm(x)
   n=x(:)'*x(:);
end