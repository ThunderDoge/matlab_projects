function [min,max]=minmax(x,s)
max=-Inf;
min=Inf;
for i=1:s, 
    if max < x(i), max=x(i); end
    if min > x(i), min=x(i); end
end
end
    
